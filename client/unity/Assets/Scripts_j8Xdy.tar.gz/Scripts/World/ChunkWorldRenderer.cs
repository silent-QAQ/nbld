using System.Collections.Generic;
using NBLD.Protocol;
using UnityEngine;

namespace NBLD.World
{
    public class ChunkWorldRenderer : MonoBehaviour
    {
        [SerializeField] private int tileSize = 1;
        [SerializeField] private int tileStep = 4;

        private readonly Dictionary<string, ChunkRenderRoot> _renderedChunks = new Dictionary<string, ChunkRenderRoot>();
        private Sprite _tileSprite;
        private bool _chunkHighlightEnabled;

        public float CellWorldSize => tileSize * tileStep;

        public void ApplyWindow(ChunkWindowResponse window)
        {
            if (window == null || window.chunks == null)
            {
                return;
            }

            EnsureSprite();

            if (window.unloadedChunks != null)
            {
                foreach (var unloaded in window.unloadedChunks)
                {
                    RemoveChunk(unloaded);
                }
            }

            foreach (var chunk in window.chunks)
            {
                RenderChunk(chunk, window.chunkTileSize);
            }
        }

        private void RenderChunk(ChunkSnapshot chunk, int chunkTileSizeValue)
        {
            if (chunk == null || chunk.coord == null)
            {
                return;
            }

            var key = ChunkKey(chunk.coord);
            if (!_renderedChunks.TryGetValue(key, out var renderRoot))
            {
                renderRoot = CreateChunkRenderRoot(key);
                _renderedChunks[key] = renderRoot;
            }

            renderRoot.Snapshot = chunk;
            renderRoot.Root.SetActive(true);
            var mapOffset = ParseMapOffset(chunk.coord.mapId, chunkTileSizeValue);
            renderRoot.Root.transform.position = new Vector3(
                mapOffset.x + (chunk.coord.chunkX * chunkTileSizeValue * tileSize),
                mapOffset.y + (chunk.coord.chunkY * chunkTileSizeValue * tileSize),
                0f
            );

            var tileCount = chunk.tiles != null ? chunk.tiles.Length : 0;
            EnsureTilePool(renderRoot, tileCount);

            for (var i = 0; i < renderRoot.Tiles.Count; i++)
            {
                var tileGO = renderRoot.Tiles[i];
                if (i >= tileCount)
                {
                    tileGO.SetActive(false);
                    continue;
                }

                var tile = chunk.tiles[i];
                tileGO.name = $"Tile_{tile.x}_{tile.y}";
                tileGO.transform.localPosition = new Vector3(tile.x * tileSize, tile.y * tileSize, 0f);
                tileGO.transform.localScale = new Vector3(tileStep * tileSize, tileStep * tileSize, 1f);

                var renderer = tileGO.GetComponent<SpriteRenderer>();
                renderer.sprite = _tileSprite;
                renderer.color = ColorForTerrain(tile.terrain);
                renderer.sortingOrder = -5;
                tileGO.SetActive(true);
            }

            UpdateChunkBorder(renderRoot, chunkTileSizeValue);
        }

        private void RemoveChunk(ChunkCoord coord)
        {
            if (coord == null)
            {
                return;
            }

            var key = ChunkKey(coord);
            if (_renderedChunks.TryGetValue(key, out var existing))
            {
                existing.Root.SetActive(false);
            }
        }

        private void SafeDestroy(Object target)
        {
            if (target == null)
            {
                return;
            }

            if (Application.isPlaying)
            {
                Destroy(target);
                return;
            }

            DestroyImmediate(target);
        }

        private string ChunkKey(ChunkCoord coord)
        {
            return $"{coord.mapId}_{coord.chunkX}_{coord.chunkY}";
        }

        private Vector2 ParseMapOffset(string mapId, int chunkTileSizeValue)
        {
            if (string.IsNullOrWhiteSpace(mapId))
            {
                return Vector2.zero;
            }

            var parts = mapId.Split('_');
            if (parts.Length != 3)
            {
                return Vector2.zero;
            }

            if (!int.TryParse(parts[1], out var mapX) || !int.TryParse(parts[2], out var mapY))
            {
                return Vector2.zero;
            }

            var mapWorldSize = 6400 * chunkTileSizeValue * tileSize;
            return new Vector2(mapX * mapWorldSize, mapY * mapWorldSize);
        }

        private ChunkRenderRoot CreateChunkRenderRoot(string key)
        {
            var root = new GameObject(key);
            root.transform.SetParent(transform, false);
            return new ChunkRenderRoot
            {
                Root = root,
                Tiles = new List<GameObject>(),
                Border = CreateBorderRoot(root.transform),
            };
        }

        public string GetTerrainAtWorldPosition(Vector3 worldPosition)
        {
            foreach (var pair in _renderedChunks)
            {
                var renderRoot = pair.Value;
                if (renderRoot.Snapshot == null || !renderRoot.Root.activeSelf)
                {
                    continue;
                }

                var local = worldPosition - renderRoot.Root.transform.position;
                var chunkTileSizeValue = renderRoot.Snapshot.tiles != null && renderRoot.Snapshot.tiles.Length > 0 ? 80 : 80;
                var chunkWorldSize = chunkTileSizeValue * tileSize;
                if (local.x < 0f || local.y < 0f || local.x >= chunkWorldSize || local.y >= chunkWorldSize)
                {
                    continue;
                }

                if (renderRoot.Snapshot.tiles == null)
                {
                    return renderRoot.Snapshot.biome;
                }

                var bestDistance = float.MaxValue;
                var bestTerrain = renderRoot.Snapshot.biome;
                for (var i = 0; i < renderRoot.Snapshot.tiles.Length; i++)
                {
                    var tile = renderRoot.Snapshot.tiles[i];
                    var dx = local.x - tile.x * tileSize;
                    var dy = local.y - tile.y * tileSize;
                    var distance = dx * dx + dy * dy;
                    if (distance < bestDistance)
                    {
                        bestDistance = distance;
                        bestTerrain = string.IsNullOrWhiteSpace(tile.terrain) ? renderRoot.Snapshot.biome : tile.terrain;
                    }
                }

                return bestTerrain;
            }

            return "-";
        }

        private void EnsureTilePool(ChunkRenderRoot renderRoot, int requiredTiles)
        {
            while (renderRoot.Tiles.Count < requiredTiles)
            {
                var tileGO = new GameObject($"Tile_{renderRoot.Tiles.Count}");
                tileGO.transform.SetParent(renderRoot.Root.transform, false);
                var renderer = tileGO.AddComponent<SpriteRenderer>();
                renderer.sprite = _tileSprite;
                renderRoot.Tiles.Add(tileGO);
            }
        }

        public bool ToggleChunkHighlight()
        {
            _chunkHighlightEnabled = !_chunkHighlightEnabled;
            foreach (var pair in _renderedChunks)
            {
                if (pair.Value.Border != null)
                {
                    pair.Value.Border.gameObject.SetActive(_chunkHighlightEnabled && pair.Value.Root.activeSelf);
                }
            }

            return _chunkHighlightEnabled;
        }

        private Transform CreateBorderRoot(Transform parent)
        {
            var root = new GameObject("Border").transform;
            root.SetParent(parent, false);
            root.gameObject.SetActive(false);

            CreateBorderLine(root, "Top");
            CreateBorderLine(root, "Bottom");
            CreateBorderLine(root, "Left");
            CreateBorderLine(root, "Right");
            return root;
        }

        private void CreateBorderLine(Transform parent, string lineName)
        {
            var line = new GameObject(lineName);
            line.transform.SetParent(parent, false);
            var renderer = line.AddComponent<SpriteRenderer>();
            renderer.sprite = _tileSprite;
            renderer.color = new Color(1f, 0.92f, 0.2f, 0.95f);
            renderer.sortingOrder = 20;
        }

        private void UpdateChunkBorder(ChunkRenderRoot renderRoot, int chunkTileSizeValue)
        {
            if (renderRoot.Border == null)
            {
                return;
            }

            var worldSize = chunkTileSizeValue * tileSize;
            var thickness = Mathf.Max(1f, tileSize * 0.4f);

            var top = renderRoot.Border.Find("Top");
            var bottom = renderRoot.Border.Find("Bottom");
            var left = renderRoot.Border.Find("Left");
            var right = renderRoot.Border.Find("Right");

            ConfigureBorderLine(top, new Vector3(worldSize * 0.5f, worldSize, 0f), new Vector3(worldSize, thickness, 1f));
            ConfigureBorderLine(bottom, new Vector3(worldSize * 0.5f, 0f, 0f), new Vector3(worldSize, thickness, 1f));
            ConfigureBorderLine(left, new Vector3(0f, worldSize * 0.5f, 0f), new Vector3(thickness, worldSize, 1f));
            ConfigureBorderLine(right, new Vector3(worldSize, worldSize * 0.5f, 0f), new Vector3(thickness, worldSize, 1f));

            renderRoot.Border.gameObject.SetActive(_chunkHighlightEnabled && renderRoot.Root.activeSelf);
        }

        private void ConfigureBorderLine(Transform line, Vector3 localPosition, Vector3 localScale)
        {
            if (line == null)
            {
                return;
            }

            line.localPosition = localPosition;
            line.localScale = localScale;
        }

        private void EnsureSprite()
        {
            if (_tileSprite != null)
            {
                return;
            }

            var texture = new Texture2D(1, 1);
            texture.SetPixel(0, 0, Color.white);
            texture.Apply();
            _tileSprite = Sprite.Create(texture, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1f);
        }

        private Color ColorForTerrain(string terrain)
        {
            switch (terrain)
            {
                case "broadleaf_forest":
                    return new Color(0.18f, 0.42f, 0.2f, 1f);
                case "conifer_forest":
                    return new Color(0.14f, 0.28f, 0.18f, 1f);
                case "lake":
                case "river":
                    return new Color(0.2f, 0.45f, 0.75f, 1f);
                case "lake_bottom":
                    return new Color(0.14f, 0.28f, 0.42f, 1f);
                case "ocean":
                    return new Color(0.1f, 0.26f, 0.6f, 1f);
                case "tropical_ocean":
                    return new Color(0.08f, 0.5f, 0.72f, 1f);
                case "ice_ocean":
                    return new Color(0.72f, 0.86f, 0.92f, 1f);
                case "sea_floor":
                    return new Color(0.18f, 0.34f, 0.46f, 1f);
                case "desert":
                    return new Color(0.84f, 0.74f, 0.38f, 1f);
                case "gobi":
                    return new Color(0.69f, 0.6f, 0.42f, 1f);
                case "beach":
                    return new Color(0.9f, 0.84f, 0.62f, 1f);
                case "mountain":
                    return new Color(0.42f, 0.42f, 0.46f, 1f);
                case "plateau":
                    return new Color(0.56f, 0.5f, 0.38f, 1f);
                case "snow_plain":
                    return new Color(0.92f, 0.94f, 0.98f, 1f);
                case "tropical_grassland":
                    return new Color(0.58f, 0.68f, 0.22f, 1f);
                case "plain":
                    return new Color(0.52f, 0.76f, 0.42f, 1f);
                case "grassland":
                    return new Color(0.34f, 0.66f, 0.24f, 1f);
                default:
                    return new Color(0.36f, 0.58f, 0.32f, 1f);
            }
        }

        private class ChunkRenderRoot
        {
            public GameObject Root;
            public List<GameObject> Tiles;
            public Transform Border;
            public ChunkSnapshot Snapshot;
        }
    }
}
